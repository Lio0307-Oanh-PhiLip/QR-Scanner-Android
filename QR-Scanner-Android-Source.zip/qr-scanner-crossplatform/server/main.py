import os, secrets, time, logging
from typing import Set
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

APP_TOKEN = os.getenv('QRSCANNER_TOKEN', 'CHANGE_ME_TO_A_LONG_RANDOM_TOKEN')
HOST = os.getenv('QRSCANNER_HOST', '0.0.0.0')
PORT = int(os.getenv('QRSCANNER_PORT', '8765'))
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
app = FastAPI(title='QR Scanner Bridge', version='0.1.0')
app.add_middleware(CORSMiddleware, allow_origins=['chrome-extension://*'], allow_methods=['POST','GET'], allow_headers=['*'])
clients: Set[WebSocket] = set()

class ScanPayload(BaseModel):
    text: str = Field(min_length=1, max_length=4096)
    device_id: str = Field(default='android', max_length=128)
    scan_id: str = Field(default_factory=lambda: secrets.token_hex(8), max_length=128)
    timestamp: int = Field(default_factory=lambda: int(time.time() * 1000))

@app.get('/')
def root():
    return {'app':'QR Scanner Bridge','version':'0.1.0','status':'running','extension_clients':len(clients),'hint':'Use /health to check status.'}

@app.get('/health')
def health():
    return {'status':'ok','extension_clients':len(clients)}

def check_token(token: str | None):
    if not APP_TOKEN or APP_TOKEN == 'CHANGE_ME_TO_A_LONG_RANDOM_TOKEN':
        raise HTTPException(status_code=503, detail='Set QRSCANNER_TOKEN to a private token before use.')
    if not token or not secrets.compare_digest(token, APP_TOKEN):
        raise HTTPException(status_code=401, detail='Invalid token')

@app.post('/api/scan')
async def receive_scan(payload: ScanPayload, x_qr_token: str | None = Header(default=None)):
    check_token(x_qr_token)
    message = {'type':'scan','text':payload.text,'device_id':payload.device_id,'scan_id':payload.scan_id,'timestamp':payload.timestamp}
    dead=[]
    for ws in list(clients):
        try: await ws.send_json(message)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)
    logging.info('Scan received (%s chars), forwarded to %d browser(s)', len(payload.text), len(clients))
    return {'ok':True,'forwarded_to':len(clients),'scan_id':payload.scan_id}

@app.websocket('/ws/extension')
async def extension_socket(ws: WebSocket):
    token = ws.query_params.get('token', '')
    if APP_TOKEN == 'CHANGE_ME_TO_A_LONG_RANDOM_TOKEN' or not secrets.compare_digest(token, APP_TOKEN):
        await ws.close(code=1008, reason='Invalid token; configure server and extension token')
        return
    await ws.accept(); clients.add(ws)
    await ws.send_json({'type':'status','status':'connected'})
    logging.info('Browser extension connected; total=%d', len(clients))
    try:
        while True:
            # Keepalive messages from extension; no commands are executed here.
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        logging.warning('WebSocket ended: %s', exc)
    finally:
        clients.discard(ws)
        logging.info('Browser extension disconnected; total=%d', len(clients))

if __name__ == '__main__':
    uvicorn.run(app, host=HOST, port=PORT)

# QR Scanner Bridge — gói cài đặt tự động hóa

Đây vẫn là bản thử nghiệm cần kiểm tra với website thật; chưa thể cam kết mọi luồng nhập/xóa dữ liệu được đồng bộ hai chiều. Website đích là `https://sc-warehouse.vercel.app/`.

## Linux Mint — cài phần server tự động
1. Giải nén ZIP.
2. Nhấp phải `install-linux.sh` → Properties → Permissions → bật “Allow executing file as program”, hoặc mở Terminal trong thư mục và chạy `./install-linux.sh`.
3. Sau khi cài, mở menu ứng dụng: **QR Scanner Bridge - Khởi động**.
4. Mở **QR Scanner Bridge - Cài tiện ích trình duyệt**. Bật Developer mode → Load unpacked → chọn `~/.local/share/qr-scanner-bridge/extension`.
5. Token riêng nằm trong `~/.local/share/qr-scanner-bridge/token.txt`.

## Windows
Chạy PowerShell với quyền người dùng trong thư mục đã giải nén: `powershell -ExecutionPolicy Bypass -File .\install-windows.ps1`. Cần cài Python 3 từ python.org nếu máy chưa có. Sau đó dùng `Start-QR-Scanner.ps1` trong `%LOCALAPPDATA%\QRScannerBridge` để chạy server; tải extension bằng “Load unpacked” một lần.

## APK Android
Thư mục `android/` là mã nguồn, KHÔNG phải APK đã build. Cần build bằng Android Studio/Android SDK trước khi cài lên điện thoại. Khi chạy, nhập IP LAN của máy tính, cổng `8765`, và token trong file `token.txt`.

## Giới hạn không thể bỏ qua
- Chrome/Edge không cho tiện ích chưa được cửa hàng/đơn vị quản trị phê duyệt tự cài im lặng; cần thao tác Load unpacked một lần.
- Mã QR được đẩy vào trang đang mở bằng sự kiện JavaScript. Nếu website yêu cầu bàn phím vật lý thật, phương án này không đủ.
- Công cụ này chỉ chuyển mã quét; nó không có quyền kiểm soát nguồn dữ liệu hay bảo đảm xóa dữ liệu trên website sẽ đồng bộ sang APK.
- Chỉ dùng trên mạng nội bộ tin cậy; không mở cổng 8765 ra Internet.


Yêu cầu Python 3.10+.
```bash
cd server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export QRSCANNER_TOKEN="THAY_BANG_CHUOI_NGAU_NHIEN_DAI"
python main.py
```
Mặc định lắng nghe cổng `8765` trên mọi giao diện mạng. Mở `http://127.0.0.1:8765/health` trên PC để kiểm tra.

## 2. Chạy server trên Windows
Cài Python 3.10+; mở PowerShell trong thư mục `server`:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:QRSCANNER_TOKEN="THAY_BANG_CHUOI_NGAU_NHIEN_DAI"
python main.py
```
Nếu điện thoại không gửi được, cho phép Python trên mạng Private trong Windows Firewall. Không mở cổng ra Internet.

## 3. Cấu hình tiện ích Chrome/Edge
1. Tạo chuỗi token dài ngẫu nhiên, ví dụ bằng `python -c "import secrets; print(secrets.token_urlsafe(32))"`.
2. Đặt cùng chuỗi vào biến `QRSCANNER_TOKEN` của server và `extension/config.js` tại `token`.
3. Trong Chrome/Edge mở `chrome://extensions` hoặc `edge://extensions`.
4. Bật **Developer mode** → **Load unpacked** → chọn thư mục `extension`.
5. Nếu server chạy trên chính máy mở trình duyệt, giữ `ws://127.0.0.1:8765/ws/extension`. Nếu server chạy ở máy khác, sửa `serverUrl` thành `ws://IP_MAY_CHAY_SERVER:8765/ws/extension` và cập nhật `host_permissions` trong `manifest.json` tương ứng.
6. Tải lại extension sau khi sửa cấu hình.

## 4. Cài APK Android
Mở thư mục `android/` bằng Android Studio, chờ Gradle Sync, kết nối điện thoại bật USB debugging rồi chọn Run. Để tạo APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Xem `android/README.md` để cấu hình IP server và token. Điện thoại phải truy cập được IP của máy chạy server trong cùng LAN.

## 5. Quy trình sử dụng
1. Khởi động server trên máy Linux hoặc Windows đang chạy Chrome/Edge.
2. Mở website công ty, đăng nhập và vào đúng màn hình kho.
3. Nhấp vào ô “Bắn mã vạch vào đây...” để đặt focus.
4. Mở APK, nhập địa chỉ server (IP LAN của PC, ví dụ `192.168.1.20`), cổng `8765` và token; kết nối rồi quét.
5. Kiểm tra một mã thử trước khi quét hàng loạt. Enter đang bật mặc định; có thể tắt trong `extension/config.js` nếu website xử lý sai.

## Bảo mật
- Dùng mạng LAN tin cậy, token dài ngẫu nhiên, không commit token thật vào kho công khai.
- Server hiện dùng HTTP/WS trên LAN, không mã hóa. Không chuyển tiếp cổng ra Internet; với mạng không tin cậy cần TLS/VPN.
- Tool không thu thập hoặc đồng bộ dữ liệu website; chỉ chuyển chuỗi QR nhận được.

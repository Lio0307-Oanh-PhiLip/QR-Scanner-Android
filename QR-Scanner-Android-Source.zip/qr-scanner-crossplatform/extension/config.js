// MUST match QRSCANNER_TOKEN configured on the server.
// Use a long random value. Do not publish this extension with your token embedded.
const QR_CONFIG = {
  serverUrl: 'ws://127.0.0.1:8765/ws/extension',
  token: 'REPLACE_WITH_THE_SAME_PRIVATE_TOKEN',
  appendEnter: true
};

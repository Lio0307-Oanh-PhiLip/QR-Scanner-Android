function refresh(){chrome.runtime.sendMessage({type:'get-status'},r=>{const e=document.getElementById('status');e.textContent=(r?.status||'unknown')+(r?.lastError?' — '+r.lastError:'');});}
document.getElementById('reconnect').addEventListener('click',()=>chrome.runtime.sendMessage({type:'reconnect'},refresh));refresh();setInterval(refresh,1500);

importScripts('config.js');
let socket = null;
let reconnectTimer = null;
let status = 'disconnected';
let lastError = '';
function setStatus(s, error='') {
  status=s; lastError=error;
  chrome.storage.local.set({qrBridgeStatus:status, qrBridgeError:lastError});
  chrome.action.setBadgeText({text: s === 'connected' ? 'ON' : '!'});
  chrome.action.setBadgeBackgroundColor({color: s === 'connected' ? '#16803c' : '#b45309'});
}
function connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
  if (!QR_CONFIG.token || QR_CONFIG.token.includes('REPLACE_')) { setStatus('setup required','Set token in config.js'); return; }
  setStatus('connecting');
  try {
    socket = new WebSocket(`${QR_CONFIG.serverUrl}?token=${encodeURIComponent(QR_CONFIG.token)}`);
    socket.onopen = () => setStatus('connected');
    socket.onmessage = async (event) => {
      let data; try { data=JSON.parse(event.data); } catch { return; }
      if (data.type !== 'scan' || typeof data.text !== 'string') return;
      try {
        const tabs = await chrome.tabs.query({active:true, lastFocusedWindow:true});
        if (!tabs.length || !tabs[0].id) return;
        await chrome.tabs.sendMessage(tabs[0].id, {type:'qr-scan', text:data.text, appendEnter:QR_CONFIG.appendEnter, scanId:data.scan_id});
      } catch (e) { setStatus('connected', 'Open the warehouse page and click its scan input.'); }
    };
    socket.onerror = () => setStatus('error','Cannot connect to local QR server');
    socket.onclose = (event) => { setStatus('disconnected', `WebSocket closed (${event.code})`); clearTimeout(reconnectTimer); reconnectTimer=setTimeout(connect, 2500); };
  } catch(e) { setStatus('error',String(e)); reconnectTimer=setTimeout(connect,2500); }
}
chrome.runtime.onInstalled.addListener(connect);
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'get-status') { sendResponse({status,lastError}); return true; }
  if (msg?.type === 'reconnect') { try { socket?.close(); } catch {} connect(); sendResponse({ok:true}); return true; }
  if (msg?.type === 'set-enter' && typeof msg.value === 'boolean') { QR_CONFIG.appendEnter=msg.value; sendResponse({ok:true}); return true; }
});
connect();

function findScanInput() {
  const candidates = [...document.querySelectorAll('input:not([type="hidden"]):not([disabled]), textarea:not([disabled])')].filter(el => {
    const r=el.getBoundingClientRect(), s=getComputedStyle(el);
    return r.width>0 && r.height>0 && s.visibility!=='hidden' && s.display!=='none';
  });
  const focused = document.activeElement;
  if (focused && candidates.includes(focused)) return focused;
  // The company page's scan field may be identified by its placeholder.
  return candidates.find(el => /bắn mã vạch|barcode|scan|quét/i.test((el.placeholder||'')+' '+(el.getAttribute('aria-label')||''))) || null;
}
function insertLikeScanner(text, appendEnter) {
  let el = findScanInput();
  if (!el) { console.warn('[QR Scanner Bridge] No focused/recognizable input. Click the website scan field first.'); return false; }
  el.focus();
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
  if (setter) setter.call(el, text); else el.value=text;
  el.dispatchEvent(new Event('input',{bubbles:true, composed:true}));
  el.dispatchEvent(new Event('change',{bubbles:true, composed:true}));
  if (appendEnter) {
    for (const type of ['keydown','keypress','keyup']) {
      el.dispatchEvent(new KeyboardEvent(type,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true,composed:true}));
    }
  }
  return true;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'qr-scan' && typeof msg.text === 'string') {
    const ok=insertLikeScanner(msg.text, !!msg.appendEnter);
    sendResponse({ok});
  }
  return true;
});

# QR Scanner Bridge — Android

APK này chỉ quét QR và chuyển nguyên văn nội dung đến server trên máy tính qua HTTP trong mạng LAN. Ứng dụng không kiểm tra nghiệp vụ kho; website tự xử lý. Camera chỉ quét QR, không tự gửi lại liên tục khi mã vẫn nằm yên trước ống kính; đưa mã ra khỏi khung rồi quét lại để gửi lần nữa.

## Cấu hình một lần
1. Cài APK, mở app và cấp quyền Camera.
2. Điện thoại và máy tính phải cùng mạng Wi-Fi.
3. Nhập IP LAN của máy tính (không nhập `127.0.0.1`), cổng `8765`, và token do bộ cài máy tính tạo ở `~/.local/share/qr-scanner-bridge/token.txt` (Linux) hoặc `%LOCALAPPDATA%\QRScannerBridge\token.txt` (Windows).
4. Chọn **LƯU & BẮT ĐẦU QUÉT**. IP/cổng/token được lưu trên điện thoại.

## Tạo APK
Dự án dùng Android Gradle Plugin 8.5.2, Kotlin 2.0.10, compile SDK 35. Để tạo APK trên máy có Android SDK/Gradle, chạy `gradle assembleDebug` trong thư mục `android`. APK đầu ra là `android/app/build/outputs/apk/debug/app-debug.apk`.

Repo cũng có workflow `.github/workflows/build-android-apk.yml` để build APK bằng GitHub Actions và tải artifact `QR-Scanner-Bridge-APK`.

## Lưu ý kết nối
- Mở server trên máy tính và cho phép cổng TCP 8765 trong firewall trên mạng riêng.
- Chỉ dùng token trên mạng tin cậy; cấu hình hiện dùng HTTP nội bộ, không mở cổng server trực tiếp ra Internet.
- Trạng thái “Đã chuyển mã” chỉ xác nhận server nhận yêu cầu, không xác nhận website chấp nhận mã.

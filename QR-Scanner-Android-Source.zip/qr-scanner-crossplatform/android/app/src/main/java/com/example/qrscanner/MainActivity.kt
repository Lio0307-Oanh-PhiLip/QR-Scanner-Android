package com.example.qrscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.Barcode
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.common.InputImage
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var ipField: EditText
    private lateinit var portField: EditText
    private lateinit var tokenField: EditText
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .build()
    private val sending = AtomicBoolean(false)
    @Volatile private var lastCode = ""
    @Volatile private var lastSeenAt = 0L
    @Volatile private var lastSentAt = 0L
    private val prefs by lazy { getSharedPreferences("qr_bridge", MODE_PRIVATE) }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Cần cấp quyền camera để quét QR."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 10)
        }
        root.addView(TextView(this).apply { text = "QR Scanner Bridge"; textSize = 24f })
        root.addView(TextView(this).apply { text = "Địa chỉ IP máy tính cùng Wi-Fi:" })
        ipField = EditText(this).apply {
            hint = "192.168.1.20"
            setSingleLine()
            setText(prefs.getString("ip", ""))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        root.addView(ipField)
        portField = EditText(this).apply {
            hint = "8765"
            setSingleLine()
            setText(prefs.getString("port", "8765"))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(TextView(this).apply { text = "Cổng server:" })
        root.addView(portField)
        tokenField = EditText(this).apply {
            hint = "Token kết nối từ máy tính"
            setSingleLine()
            setText(prefs.getString("token", ""))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(TextView(this).apply { text = "Mã kết nối:" })
        root.addView(tokenField)
        val start = Button(this).apply { text = "LƯU & BẮT ĐẦU QUÉT" }
        root.addView(start)
        status = TextView(this).apply {
            text = "Nhập IP và mã kết nối một lần. Điện thoại và máy tính phải cùng mạng Wi-Fi."
            textSize = 14f
        }
        root.addView(status)
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(preview)
        setContentView(root)
        start.setOnClickListener {
            val ip = ipField.text.toString().trim()
            val port = portField.text.toString().trim().ifBlank { "8765" }
            val token = tokenField.text.toString().trim()
            if (ip.isBlank() || token.isBlank()) {
                status.text = "Nhập IP máy tính và mã kết nối trước."
                return@setOnClickListener
            }
            val portNumber = port.toIntOrNull()
            if (portNumber == null || portNumber !in 1..65535) {
                status.text = "Cổng không hợp lệ. Hãy dùng 8765 nếu chưa đổi cấu hình."
                return@setOnClickListener
            }
            prefs.edit().putString("ip", ip).putString("port", port).putString("token", token).apply()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val options = BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
                val scanner = BarcodeScanning.getClient(options)
                analysis.setAnalyzer(cameraExecutor) { imageProxy -> processFrame(scanner, imageProxy) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                status.text = "Đang quét. Mỗi mã được gửi tự động; website tự kiểm tra mã."
            } catch (e: Exception) {
                status.text = "Không mở được camera: ${e.localizedMessage ?: "lỗi không xác định"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processFrame(scanner: com.google.mlkit.vision.barcode.BarcodeScanner, proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) { proxy.close(); return }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                val now = System.currentTimeMillis()
                val value = barcodes.firstOrNull { !it.rawValue.isNullOrEmpty() }?.rawValue
                if (value == null) {
                    synchronized(this) {
                        if (now - lastSeenAt > 900) lastCode = ""
                    }
                    return@addOnSuccessListener
                }
                synchronized(this) {
                    // A QR is sent once while it stays visible. It can be scanned again after it leaves the frame.
                    if (value == lastCode) {
                        lastSeenAt = now
                        return@addOnSuccessListener
                    }
                    lastCode = value
                    lastSeenAt = now
                    if (now - lastSentAt < 450 || !sending.compareAndSet(false, true)) return@addOnSuccessListener
                    lastSentAt = now
                }
                runOnUiThread { status.text = "Đang gửi: $value" }
                networkExecutor.execute { sendScan(value) }
            }
            .addOnFailureListener { e -> runOnUiThread { status.text = "Không đọc được QR: ${e.localizedMessage ?: "thử lại"}" } }
            .addOnCompleteListener { proxy.close() }
    }

    private fun sendScan(value: String) {
        try {
            val ip = prefs.getString("ip", "")!!.trim()
            val port = prefs.getString("port", "8765")!!.trim().ifBlank { "8765" }
            val token = prefs.getString("token", "")!!.trim()
            val body = JSONObject().put("text", value).put("device_id", android.os.Build.MODEL).toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("http://$ip:$port/api/scan")
                .header("X-QR-Token", token)
                .post(body)
                .build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw Exception("Máy tính trả HTTP ${response.code}")
                runOnUiThread { status.text = "Đã chuyển mã: $value" }
            }
        } catch (e: Exception) {
            runOnUiThread { status.text = "Gửi thất bại: ${e.localizedMessage ?: "kiểm tra Wi-Fi, IP và mã kết nối"}" }
        } finally {
            sending.set(false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        networkExecutor.shutdown()
        http.dispatcher.cancelAll()
    }
}
